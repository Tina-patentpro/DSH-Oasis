import { createElement, useEffect, useLayoutEffect, useRef, useSyncExternalStore } from 'react'

import { PanelChrome } from './PanelChrome.js'
import { PanelPages } from './PanelPages.js'
import { resolveWorkspaceId } from './project-resolution.js'

const reducedMotionCss = `
  [data-oasis-panel] { transition: left 180ms ease, width 180ms ease; }
  @media (prefers-reduced-motion: reduce) { [data-oasis-panel] { transition: none; } }
  @media (max-width: 760px) {
    [data-oasis-panel] [data-workspace-layout] { grid-template-columns: minmax(0, 1fr) !important; }
  }
`

export function createPanelActions({
  store,
  workspaceId,
  focusTargets,
  confirmClose = (message) => globalThis.confirm?.(message) === true,
}) {
  return Object.freeze({
    async activatePage(pageId) {
      await store.flushWorkspace(workspaceId)
      store.activatePage(workspaceId, pageId)
    },
    async closePage(pageId) {
      const page = store.getWorkspaceState(workspaceId).pages.find((item) => item.pageId === pageId)
      if (!page) return false
      if (page.runOrder.length > 0 && !confirmClose(
        `任务“${page.title}”包含 ${page.runOrder.length} 个运行记录。确认关闭此任务页？`,
      )) return false
      await store.flushWorkspace(workspaceId)
      store.closePage(workspaceId, pageId)
      return true
    },
    async hidePanel() {
      await store.flushWorkspace(workspaceId)
      const current = store.getWorkspaceState(workspaceId)
      if (['ready', 'saving'].includes(current.syncStatus)) {
        store.setPanelMode(workspaceId, 'hidden')
      } else {
        store.setLocalPanelMode(workspaceId, 'hidden')
      }
      focusTargets.get(workspaceId)?.focus?.()
    },
  })
}

export function OasisPanelHost({ store, focusTargets, layoutAdapter, useSessions, useWorkspaces }) {
  const currentSessionId = useSessions((snapshot) => snapshot.current)
  const workspaceItems = useWorkspaces((snapshot) => snapshot.items)
  const workspaceId = resolveWorkspaceId(currentSessionId, workspaceItems)
  const state = useSyncExternalStore(
    store.subscribe,
    () => store.peekWorkspaceState(workspaceId),
    () => store.peekWorkspaceState(workspaceId),
  )
  const panelRef = useRef(null)
  const titleRef = useRef(null)
  const layout = useSyncExternalStore(
    layoutAdapter.subscribe,
    layoutAdapter.getSnapshot,
    layoutAdapter.getSnapshot,
  )

  useEffect(() => {
    store.syncWorkspaces(workspaceItems)
    if (workspaceId !== null) {
      void Promise.all([
        store.hydrateWorkspace(workspaceId),
        store.loadWorkflowCatalog(workspaceId),
      ]).catch(() => {})
    }
  }, [store, workspaceId, workspaceItems])

  useEffect(() => () => {
    if (workspaceId !== null) void store.flushWorkspace(workspaceId).catch(() => {})
  }, [store, workspaceId])

  useLayoutEffect(() => {
    layoutAdapter.apply({
      requestedMode: workspaceId === null ? 'hidden' : state.panelMode,
      panelWidth: 360,
      panelElement: panelRef.current,
    })
  }, [layoutAdapter, state.panelMode, workspaceId])

  useEffect(() => {
    if (layout.effectiveMode !== 'hidden') titleRef.current?.focus()
  }, [layout.effectiveMode, workspaceId])

  const layoutBlocked = state.panelMode !== 'hidden'
    && layout.requestedMode === state.panelMode
    && layout.effectiveMode === 'hidden'
    && ['incompatible', 'conflict', 'faulted'].includes(layout.status)
  if (workspaceId === null || state.panelMode === 'hidden' || layoutBlocked) return null

  const effectiveMode = layout.requestedMode === state.panelMode ? layout.effectiveMode : state.panelMode
  const resolvedGeometry = effectiveMode === 'normal'
    ? { right: 0, width: 360 }
    : { left: layout.panelLeft ?? 72, right: 0 }

  const actions = createPanelActions({ store, workspaceId, focusTargets })

  return createElement('section', {
    ref: panelRef,
    'data-oasis-panel': true,
    'data-testid': 'oasis-panel',
    'data-mode': effectiveMode,
    'data-requested-mode': state.panelMode,
    'data-layout-status': layout.status,
    'data-workspace-id': workspaceId,
    'aria-label': '绿洲专业工作台',
    style: {
      position: 'fixed',
      top: 0,
      bottom: 0,
      zIndex: 1,
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0,
      overflow: 'hidden',
      borderLeft: '1px solid var(--dsw-alias-border-l2, #dedee1)',
      boxShadow: '-10px 0 28px rgba(0, 0, 0, 0.08)',
      background: 'var(--dsw-alias-bg-base, #fff)',
      color: 'var(--dsw-alias-text-primary, #202123)',
      ...resolvedGeometry,
    },
  },
  createElement('style', null, reducedMotionCss),
  createElement(PanelChrome, {
    state: { ...state, effectiveMode, layoutStatus: layout.status },
    titleRef,
    onActivatePage: (pageId) => { void actions.activatePage(pageId).catch(() => {}) },
    onClosePage: (pageId) => { void actions.closePage(pageId).catch(() => {}) },
    onCreatePage: () => store.createPage(workspaceId),
    onHide: () => { void actions.hidePanel().catch(() => {}) },
    onToggleExpanded: () => store.setPanelMode(
      workspaceId,
      state.panelMode === 'expanded' ? 'normal' : 'expanded',
    ),
  }),
  createElement(PanelPages, {
    state,
    effectiveMode,
    onSelectWorkflow: (pageId, workflowId) => store.selectWorkflow(workspaceId, pageId, workflowId),
    onRenamePage: (pageId, title) => store.renamePage(workspaceId, pageId, title),
    onReload: () => store.reloadWorkspace(workspaceId),
    onUpdateForm: (pageId, fieldId, value) => store.updateFormValue(workspaceId, pageId, fieldId, value),
    onMaterialDraft: (pageId, path, confirmed) => store.setMaterialDraft(workspaceId, pageId, path, confirmed),
    onAddMaterial: (pageId) => { void store.addMaterial(workspaceId, pageId).catch(() => {}) },
    onRefreshMaterial: (pageId, referenceId) => {
      void store.refreshMaterial(workspaceId, pageId, referenceId).catch(() => {})
    },
    onRemoveMaterial: (pageId, referenceId, confirmed) => {
      if (confirmed) void store.removeMaterial(workspaceId, pageId, referenceId, true).catch(() => {})
    },
    onGenerate: (pageId) => { void store.createRun(workspaceId, pageId).catch(() => {}) },
    onActivateRun: (pageId, runId) => store.activateRun(workspaceId, pageId, runId),
    onReviewNote: (pageId, note) => store.setReviewNote(workspaceId, pageId, note),
    onReview: (pageId, runId, status, note) => {
      void store.reviewRun(workspaceId, pageId, runId, status, note).catch(() => {})
    },
    onWritebackDraft: (pageId, directory, confirmed) => {
      store.setWritebackDraft(workspaceId, pageId, directory, confirmed)
    },
    onPrepareWriteback: (pageId, runId) => {
      void store.prepareWriteback(workspaceId, pageId, runId).catch(() => {})
    },
    onWritebackConfirm: (pageId, confirmed) => store.setWritebackConfirmation(workspaceId, pageId, confirmed),
    onCommitWriteback: (pageId) => { void store.commitWriteback(workspaceId, pageId).catch(() => {}) },
  }))
}
